<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', config('app.name')) | IT-Holding Sénégal</title>
    
    <!-- Primary Meta Tags -->
    <meta name="description" content="@yield('meta_description', 'IT-Holding est votre partenaire de confiance au Sénégal pour toutes vos solutions numériques : maintenance informatique, infrastructure réseau, vidéosurveillance et vente de matériel.')">
    <meta name="keywords" content="@yield('meta_keywords', 'IT-Holding, maintenance informatique Sénégal, infrastructure réseau Dakar, vidéosurveillance IP, vente matériel informatique, solutions numériques Sénégal')">
    <meta name="author" content="IT-Holding">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="{{ url()->current() }}">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="@yield('og_type', 'website')">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:title" content="@yield('title', config('app.name')) | IT-Holding Sénégal">
    <meta property="og:description" content="@yield('meta_description', 'IT-Holding est votre partenaire de confiance au Sénégal pour toutes vos solutions numériques.')">
    <meta property="og:image" content="@yield('og_image', asset('logo.jpeg'))">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="{{ url()->current() }}">
    <meta property="twitter:title" content="@yield('title', config('app.name')) | IT-Holding Sénégal">
    <meta property="twitter:description" content="@yield('meta_description', 'IT-Holding est votre partenaire de confiance au Sénégal pour toutes vos solutions numériques.')">
    <meta property="twitter:image" content="@yield('og_image', asset('logo.jpeg'))">

    <!-- Structured Data (JSON-LD) -->
    <script type="application/ld+json">
    {
        "@@context": "https://schema.org",
        "@@type": "Organization",
        "name": "IT-Holding",
        "url": "{{ url('/') }}",
        "logo": "{{ asset('logo.jpeg') }}",
        "contactPoint": {
            "@@type": "ContactPoint",
            "telephone": "+221 77 351 87 16",
            "contactType": "customer service",
            "areaServed": "SN",
            "availableLanguage": "French"
        },
        "sameAs": [
            "https://www.facebook.com/itholding",
            "https://www.linkedin.com/company/itholding",
            "https://twitter.com/itholding"
        ]
    }
    </script>
    <script type="application/ld+json">
    {
        "@@context": "https://schema.org",
        "@@type": "WebSite",
        "url": "{{ url('/') }}",
        "name": "IT-Holding Sénégal",
        "potentialAction": {
            "@@type": "SearchAction",
            "target": "{{ url('/shop?q={search_term_string}') }}",
            "query-input": "required name=search_term_string"
        }
    }
    </script>
    <link rel="icon" type="image/jpeg" href="{{ asset('logo.jpeg') }}">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Tailwind CSS (CDN) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                    colors: {
                        navy: {
                            50: '#fafafa',
                            100: '#f4f4f5',
                            200: '#e4e4e7',
                            300: '#a1a1aa',
                            400: '#71717a',
                            500: '#3f3f46',
                            600: '#27272a',
                            700: '#18181b',
                            800: '#0a0a0a',
                            900: '#000000',
                        },
                        gold: {
                            50: '#fef2f2',
                            100: '#fee2e2',
                            200: '#fecaca',
                            300: '#fca5a5',
                            400: '#f87171',
                            500: '#ef4444',
                            600: '#dc2626',
                            700: '#b91c1c',
                            800: '#991b1b',
                            900: '#7f1d1d',
                        },
                        gray: {
                            50: '#fafafa',
                            100: '#f4f4f5',
                            200: '#e6e7eb',
                            300: '#d1d5db',
                            400: '#9ca3af',
                            500: '#6b7280',
                            600: '#4b5563',
                            700: '#374151',
                            800: '#1f2937',
                            900: '#111827',
                        }
                    }
                }
            }
        }
    </script>

    <!-- Dark Mode Script -->
    <script>
        // Initialize dark mode from localStorage before page renders
        if (localStorage.getItem('darkMode') === 'true' ||
            (!localStorage.getItem('darkMode') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        }

        // Toggle dark mode function
        function toggleDarkMode() {
            document.documentElement.classList.toggle('dark');
            const isDark = document.documentElement.classList.contains('dark');
            localStorage.setItem('darkMode', isDark);
        }
    </script>

    <!-- Alpine.js (CDN) -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        [x-cloak] {
            display: none !important;
        }

        /* Cross-browser fixes for text gradients and color rendering (improves Firefox) */
        :root {
            color-scheme: light dark;
        }

        /* Ensure background-clip:text works in Firefox/Chrome and text becomes transparent to show gradient */
        .bg-clip-text,
        .text-gradient {
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            color: transparent;
        }

        /* Ensure SVG icons inherit color consistently */
        svg {
            color: inherit;
        }

        /* ── Custom Red Style overrides for client-side forms and selects ── */
        body:not(.partner-page) select, 
        body:not(.partner-page) textarea,
        body:not(.partner-page) input:not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="hidden"]) {
            border: 1.5px solid #fca5a5 !important; /* solid 1.5px red-300 default border */
            transition: all 0.2s ease-in-out !important;
        }

        /* Border hover states: red-500 */
        body:not(.partner-page) select:hover:not(:focus),
        body:not(.partner-page) textarea:hover:not(:focus),
        body:not(.partner-page) input:not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="hidden"]):hover:not(:focus) {
            border-color: #ef4444 !important; /* red-500 */
        }

        /* Focus states: premium crimson red border and glowing focus ring */
        body:not(.partner-page) select:focus,
        body:not(.partner-page) textarea:focus,
        body:not(.partner-page) input:not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="hidden"]):focus {
            border-color: #dc2626 !important; /* red-600 */
            --tw-ring-color: #ef4444 !important; /* red-500 */
            --tw-ring-opacity: 0.35 !important;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color) !important;
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color) !important;
            box-shadow: var(--tw-ring-offset-shadow) var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000) !important;
            outline: none !important;
        }

        /* Checkbox & Radio inputs: red tint & accent-color */
        body:not(.partner-page) input[type="checkbox"],
        body:not(.partner-page) input[type="radio"] {
            accent-color: #dc2626 !important;
        }

        body:not(.partner-page) input[type="checkbox"]:focus,
        body:not(.partner-page) input[type="radio"]:focus {
            --tw-ring-color: #ef4444 !important;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.3) !important;
        }

        /* ── Espace Partenaire Inputs ── */
        body.partner-page select,
        body.partner-page textarea,
        body.partner-page input:not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="hidden"]) {
            border: 1.5px solid #cbd5e1 !important; /* slate-300 */
            background-color: #ffffff !important;
            color: #27272a !important; /* navy-600 (neutre) */
            border-radius: 0.5rem !important; /* rounded-lg */
            transition: all 0.15s ease-in-out !important;
        }

        body.partner-page select:hover:not(:focus),
        body.partner-page textarea:hover:not(:focus),
        body.partner-page input:not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="hidden"]):hover:not(:focus) {
            border-color: #94a3b8 !important; /* slate-400 */
        }

        body.partner-page select:focus,
        body.partner-page textarea:focus,
        body.partner-page input:not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="hidden"]):focus {
            border-color: #dc2626 !important; /* red-600 */
            --tw-ring-color: #ef4444 !important; /* red-500 */
            --tw-ring-opacity: 0.35 !important;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color) !important;
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color) !important;
            box-shadow: var(--tw-ring-offset-shadow) var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000) !important;
            outline: none !important;
        }

        body.partner-page input[type="checkbox"],
        body.partner-page input[type="radio"] {
            accent-color: #dc2626 !important; /* red-600 */
        }

        body.partner-page input[type="checkbox"]:focus,
        body.partner-page input[type="radio"]:focus {
            --tw-ring-color: #ef4444 !important;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.3) !important;
        }
    </style>

    <style>
        :root { --ith-ink:#101b2d; --ith-navy:#0a1425; --ith-gold:#e7b65b; --ith-muted:#64748b; }
        body { font-family:Inter,ui-sans-serif,system-ui,sans-serif; background:#fff; color:#172033; }
        ::selection { background:#f3d79d; color:#101b2d; }
        nav { box-shadow:0 4px 24px rgba(15,23,42,.035); }
        nav .bg-navy-600 { background:#0a1425 !important; }
        nav .bg-navy-700 { background:#07101e !important; }
        nav .bg-white.border-b { border-color:#e8edf3 !important; }
        nav input[type=search] { border-radius:12px !important; background:#f6f8fb !important; border:1px solid #e4e9f0 !important; padding-top:13px!important; padding-bottom:13px!important; }
        nav button, nav a { transition:color .2s ease,background .2s ease,transform .2s ease; }
        nav .bg-gold-500 { background:#e7b65b !important; }
        .ith-hero { position:relative; isolation:isolate; overflow:hidden; padding:72px 0 26px; color:#fff; background:linear-gradient(116deg,#081322 0%,#101f35 58%,#142945 100%); }
        .ith-hero-grid { position:absolute; inset:0; z-index:-1; opacity:.18; background-image:linear-gradient(rgba(255,255,255,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.08) 1px,transparent 1px); background-size:54px 54px; mask-image:linear-gradient(90deg,black,transparent 95%); }
        .ith-hero:after { content:''; position:absolute; z-index:-1; width:600px;height:600px;border-radius:50%;right:-180px;top:-300px;background:rgba(231,182,91,.10);filter:blur(6px); }
        .ith-hero-inner { display:grid;grid-template-columns:1.03fr .97fr;gap:46px;align-items:center;min-height:500px; }
        .ith-hero-copy { padding:16px 0 26px;max-width:620px; }
        .ith-eyebrow { display:flex;align-items:center;gap:10px;color:#e9c77f;font-size:10px;font-weight:800;letter-spacing:.19em;margin-bottom:24px; }
        .ith-pulse,.ith-live i,.ith-status-line i { display:inline-block;width:7px;height:7px;border-radius:50%;background:#65d6a0;box-shadow:0 0 0 4px rgba(101,214,160,.12); }
        .ith-hero h1 { margin:0 0 22px;font-size:clamp(42px,5.2vw,68px);line-height:1.04;letter-spacing:-.055em;font-weight:750;color:#fff; }
        .ith-hero h1 span { color:#e7b65b; }
        .ith-hero-copy>p { max-width:510px;color:#b8c5d6;font-size:16px;line-height:1.85;margin:0 0 30px; }
        .ith-hero-actions { display:flex;align-items:center;gap:14px;flex-wrap:wrap; }
        .ith-btn-primary,.ith-btn-secondary { display:inline-flex;align-items:center;justify-content:center;gap:18px;padding:15px 20px;border-radius:9px;font-size:13px;font-weight:750;text-decoration:none; }
        .ith-btn-primary { background:#e7b65b;color:#111b2a;box-shadow:0 10px 30px rgba(231,182,91,.18); }
        .ith-btn-primary:hover { background:#f0c977;transform:translateY(-2px); }
        .ith-btn-secondary { border:1px solid rgba(255,255,255,.22);color:#fff;background:rgba(255,255,255,.035); }
        .ith-btn-secondary:hover { background:rgba(255,255,255,.1); }
        .ith-proof-row { display:flex;gap:22px;flex-wrap:wrap;margin-top:39px;padding-top:23px;border-top:1px solid rgba(255,255,255,.12); }
        .ith-proof { display:flex;align-items:center;gap:10px; }
        .ith-proof-icon { width:30px;height:30px;display:grid;place-items:center;border:1px solid rgba(231,182,91,.35);border-radius:9px;color:#e7b65b;font-size:14px; }
        .ith-proof b,.ith-proof small { display:block; }.ith-proof b {font-size:11px;color:#f4f6f9}.ith-proof small{font-size:10px;color:#9eafc3;margin-top:3px}
        .ith-visual { min-height:440px;position:relative;display:flex;align-items:center;justify-content:center; }
        .ith-glow { position:absolute;width:330px;height:330px;border-radius:50%;background:rgba(64,116,170,.2);filter:blur(50px); }
        .ith-orbit { position:absolute;border:1px solid rgba(231,182,91,.18);border-radius:50%;transform:rotate(-25deg); }
        .ith-orbit-one { width:470px;height:270px; }.ith-orbit-two { width:410px;height:340px;transform:rotate(42deg);border-color:rgba(255,255,255,.09); }
        .ith-device-card { position:relative;width:min(100%,440px);border-radius:18px;border:1px solid rgba(255,255,255,.18);background:linear-gradient(145deg,rgba(26,43,66,.96),rgba(10,22,38,.97));box-shadow:0 35px 90px rgba(0,0,0,.36);overflow:hidden;transform:rotate(-1.5deg); }
        .ith-device-top { display:flex;align-items:center;justify-content:space-between;gap:10px;padding:15px 17px;border-bottom:1px solid rgba(255,255,255,.1);font-size:8px;letter-spacing:.11em;color:#91a2b8; }
        .ith-window-dots { display:flex;gap:4px; }.ith-window-dots i {width:6px;height:6px;border-radius:50%;background:#64748b}.ith-window-dots i:first-child{background:#e7b65b}
        .ith-live { display:flex;align-items:center;gap:7px;font-size:7px;color:#a9e9c9;letter-spacing:.06em; }
        .ith-device-body { padding:28px 27px 20px; }.ith-device-kicker{font-size:8px;letter-spacing:.18em;color:#9dafc4;font-weight:800;margin-bottom:13px}
        .ith-device-title {font-size:29px;line-height:1.2;font-weight:350;letter-spacing:-.04em;color:#fff}.ith-device-title strong{color:#e7b65b;font-weight:750}
        .ith-metric-grid {display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:25px}
        .ith-metric {padding:13px;border-radius:10px;border:1px solid rgba(255,255,255,.09);background:rgba(255,255,255,.035)}
        .ith-metric-icon {display:grid;place-items:center;width:28px;height:28px;border-radius:8px;background:rgba(231,182,91,.12);color:#e7b65b;margin-bottom:9px;font-size:16px}
        .ith-metric b,.ith-metric small {display:block}.ith-metric b{font-size:11px;color:#f6f8fb}.ith-metric small{font-size:9px;color:#9bacc0;margin-top:4px}
        .ith-status-line {display:flex;justify-content:space-between;gap:12px;border-top:1px solid rgba(255,255,255,.1);padding-top:15px;margin-top:18px;font-size:8px;color:#9bacc0;letter-spacing:.07em}.ith-status-line span:first-child{display:flex;align-items:center;gap:8px}.ith-status-line i{width:6px;height:6px}
        .ith-float-tag {position:absolute;display:flex;align-items:center;gap:10px;background:#fff;color:#172033;border-radius:12px;padding:12px 15px;box-shadow:0 16px 40px rgba(0,0,0,.2);font-size:10px;font-weight:750; }
        .ith-tag-top {top:42px;right:-2px;}.ith-tag-top span{font-size:16px;color:#c18b28}.ith-tag-bottom{bottom:33px;left:-10px}.ith-check{display:grid;place-items:center;width:30px;height:30px;border-radius:9px;background:#e4f7ed;color:#16834c;font-size:15px}.ith-tag-bottom b,.ith-tag-bottom small{display:block}.ith-tag-bottom small{font-size:9px;font-weight:500;color:#718096;margin-top:4px}
        .ith-hero-bottom {display:flex;align-items:center;gap:17px;margin-top:25px;color:#7f91a8;font-size:8px;font-weight:800;letter-spacing:.17em}.ith-bottom-line{height:1px;flex:1;background:rgba(255,255,255,.12)}
        .trust-card {padding:23px 16px!important; }
        main section:not(.ith-hero) h2 { letter-spacing:-.035em; }
        main section:not(.ith-hero) .rounded-xl, main section:not(.ith-hero) .rounded-lg { transition:box-shadow .25s ease,transform .25s ease; }
        main section:not(.ith-hero) .rounded-xl:hover { box-shadow:0 16px 38px rgba(15,23,42,.08); }
        @media(max-width:900px){.ith-hero{padding-top:48px}.ith-hero-inner{grid-template-columns:1fr;gap:10px}.ith-hero-copy{max-width:720px}.ith-visual{min-height:400px}.ith-device-card{width:min(88%,440px)}.ith-tag-top{right:3%}.ith-tag-bottom{left:3%}.ith-hero-bottom{margin-top:10px}}
        @media(max-width:560px){.ith-hero{padding:38px 0 22px}.ith-hero h1{font-size:43px}.ith-hero-copy>p{font-size:14px}.ith-eyebrow{font-size:8px;letter-spacing:.13em}.ith-hero-actions{align-items:stretch;flex-direction:column}.ith-btn-primary,.ith-btn-secondary{width:100%}.ith-proof-row{gap:15px;margin-top:28px}.ith-proof{width:calc(50% - 10px)}.ith-visual{min-height:350px;margin-top:4px}.ith-device-card{width:94%}.ith-device-body{padding:22px 17px 16px}.ith-device-title{font-size:25px}.ith-metric{padding:10px}.ith-tag-top{top:10px;right:0}.ith-tag-bottom{bottom:5px;left:0}.ith-hero-bottom{font-size:7px;letter-spacing:.08em;gap:8px}.ith-hero-bottom span:last-child{max-width:44%;text-align:right}}
    </style>

    @stack('styles')
</head>

<body
    class="antialiased bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-red-400 flex flex-col min-h-screen transition-colors duration-200 {{ request()->is('partner*') || request()->is('dashboard/partner*') ? 'partner-page' : '' }}">

    @include('layouts.navigation')

    @if (session('success') || session('error'))
        <div x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 8000)" x-transition
            class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
            @if (session('success'))
                <div class="flex items-start gap-3 p-4 bg-green-50 border border-green-100 rounded-xl text-green-700 text-sm font-semibold">
                    <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <span class="flex-1">{{ session('success') }}</span>
                    <button @click="show = false" class="text-green-400 hover:text-green-600">&times;</button>
                </div>
            @endif
            @if (session('error'))
                <div class="flex items-start gap-3 p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm font-semibold">
                    <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <span class="flex-1">{{ session('error') }}</span>
                    <button @click="show = false" class="text-red-400 hover:text-red-600">&times;</button>
                </div>
            @endif
        </div>
    @endif

    <main class="flex-grow">
        @yield('content')
    </main>

    @include('layouts.footer')

    @include('partials.chat_widget')

    @stack('scripts')
</body>

</html>
