@extends('layouts.app')

@php
    $defaultImage = $product->image ?: ($product->images->first()?->path ?? null);
    $defaultImgUrl = $defaultImage 
        ? (filter_var($defaultImage, FILTER_VALIDATE_URL) 
            ? $defaultImage 
            : (preg_match('#^/?storage/#', $defaultImage) ? $defaultImage : '/storage/' . ltrim($defaultImage, '/'))) 
        : asset('logo.jpeg');
@endphp

@section('title', $product->name . ' - IT-Holding Boutique')
@section('meta_description', Str::limit(strip_tags($product->description), 160))
@section('meta_keywords', $product->name . ', ' . ($product->category->name ?? '') . ', hardware Sénégal, prix informatique Dakar')

@section('og_type', 'product')
@section('og_image', filter_var($defaultImgUrl, FILTER_VALIDATE_URL) ? $defaultImgUrl : asset(ltrim($defaultImgUrl, '/')))

@section('content')
<div class="bg-white min-h-screen">
    <!-- Breadcrumb -->
    <div class="bg-gray-50 border-b border-gray-100 py-3">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <nav class="flex text-xs text-gray-400 gap-2 items-center">
                <a href="{{ route('home') }}" class="hover:text-navy-900 flex items-center gap-1">
                    <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"/></svg>
                    Accueil
                </a>
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                <a href="{{ route('shop.index') }}" class="hover:text-navy-900">Boutique</a>
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                @if ($product->category)
                    <a href="{{ route('shop.index', ['category_id' => $product->category->id]) }}" class="hover:text-navy-900">{{ $product->category->name }}</a>
                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                @endif
                <span class="text-gold-600 font-medium truncate">{{ $product->name }}</span>
            </nav>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        @if (session('success'))
            <div class="mb-6 bg-green-50 text-green-700 p-4 rounded-lg flex items-center gap-3 border border-green-100">
                <svg class="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                <span class="text-sm font-medium">{{ session('success') }}</span>
            </div>
        @endif

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <!-- Left: Gallery -->
            <div x-data="{ mainImage: '{{ $defaultImgUrl }}' }" class="space-y-6">
                <!-- Main Image -->
                <div class="aspect-square bg-gray-50 rounded-lg overflow-hidden border border-gray-100 flex items-center justify-center p-8 group relative">
                    <img :src="mainImage" alt="{{ $product->name }}" class="max-h-full max-w-full object-contain transform group-hover:scale-105 transition-transform duration-500">
                </div>

                <!-- Thumbnails Gallery -->
                @if($product->images->count() > 0)
                <div class="relative px-8">
                    <div class="flex items-center gap-4 overflow-x-auto py-2">
                        @foreach($product->images as $img)
                            @php
                                $tPath = preg_match('#^/?storage/#', $img->path) ? $img->path : '/storage/'.ltrim($img->path, '/');
                            @endphp
                            <button @click="mainImage = '{{ $tPath }}'" 
                                class="flex-shrink-0 w-20 h-20 border-2 rounded-lg p-2 bg-white transition-all overflow-hidden"
                                :class="mainImage === '{{ $tPath }}' ? 'border-gold-500' : 'border-gray-100 hover:border-gold-200'">
                                <img src="{{ $tPath }}" class="w-full h-full object-contain">
                            </button>
                        @endforeach
                    </div>
                </div>
                @endif
            </div>

            <!-- Right: Product Info -->
            <div class="flex flex-col">
                <!-- Rating & Feedback -->
                <div class="flex items-center gap-4 mb-4">
                    <div class="flex text-gold-500">
                        @for($i=0; $i<5; $i++)
                            <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                        @endfor
                    </div>
                    <span class="text-xs font-bold text-navy-900 uppercase tracking-widest">4.7 Star Rating</span>
                    <span class="text-xs text-gray-400 whitespace-nowrap">(2,350 Retours utilisateurs)</span>
                </div>

                <!-- Title -->
                <h1 class="text-2xl lg:text-3xl font-bold text-navy-900 mb-6 leading-tight">{{ $product->name }}</h1>

                <!-- Meta Details -->
                <div class="grid grid-cols-2 gap-y-4 mb-8 text-sm">
                    <div>
                        <span class="text-gray-400 block mb-1">REF:</span>
                        <span class="font-bold text-navy-900">{{ $product->sku ?: 'IT-'.str_pad($product->id, 5, '0', STR_PAD_LEFT) }}</span>
                    </div>
                    <div>
                        <span class="text-gray-400 block mb-1">Disponibilité:</span>
                        @if($product->isPreorderable())
                            <span class="font-bold text-amber-600">En précommande (Disponible le {{ $product->available_at->format('d/m/Y') }})</span>
                        @else
                            <span class="font-bold {{ $product->stock > 0 ? 'text-green-600' : 'text-red-600' }}">{{ $product->stock > 0 ? 'En stock' : 'Rupture de stock' }}</span>
                        @endif
                    </div>
                    <div>
                        <span class="text-gray-400 block mb-1">Marque:</span>
                        <span class="font-bold text-navy-900">{{ $product->brand->name ?? 'IT-HOLDING' }}</span>
                    </div>
                    <div>
                        <span class="text-gray-400 block mb-1">Catégorie:</span>
                        <span class="font-bold text-navy-900">{{ $product->category->name ?? 'Informatique' }}</span>
                    </div>
                    @if($product->condition)
                    <div>
                        <span class="text-gray-400 block mb-1">État:</span>
                        <span class="font-bold text-navy-900">
                            @switch($product->condition)
                                @case('new') Neuf @break
                                @case('reconditioned') Reconditionné @break
                                @case('second_hand') Seconde main @break
                                @default {{ ucfirst(str_replace('_', ' ', $product->condition)) }}
                            @endswitch
                        </span>
                    </div>
                    @endif
                    <div>
                        <span class="text-gray-400 block mb-1">Garantie:</span>
                        <span class="font-bold text-navy-900">
                            @if($product->warranty_duration_months)
                                {{ $product->warranty_duration_months }} mois ({{ $product->warranty_duration_months % 12 === 0 ? ($product->warranty_duration_months / 12) . ' an(s)' : $product->warranty_duration_months . ' mois' }})
                            @else
                                Sans garantie / Standard
                            @endif
                        </span>
                    </div>
                </div>

            <!-- Bespoke Configurator Wrapper -->
            <div x-data="{ 
                basePrice: {{ $product->promo_price ?: $product->price }},
                optionsPrices: {},
                get totalPrice() {
                    let sum = this.basePrice;
                    for (let key in this.optionsPrices) {
                        sum += parseFloat(this.optionsPrices[key] || 0);
                    }
                    return sum;
                },
                updateOption(name, price) {
                    this.optionsPrices[name] = price;
                }
            }">
                <!-- Price -->
                <div class="flex items-center gap-4 mb-10">
                    <span class="text-3xl font-black text-gold-500">
                        <span x-text="totalPrice.toLocaleString('fr-FR')"></span> <span class="text-sm font-bold">CFA</span>
                    </span>
                    @if($product->promo_price && $product->promo_price < $product->price)
                        <span class="text-xl text-gray-300 line-through">{{ number_format($product->price, 0, ',', ' ') }} CFA</span>
                        @php
                            $discount = round((($product->price - $product->promo_price) / $product->price) * 100);
                        @endphp
                        <span class="bg-gold-100 text-gold-600 px-3 py-1 rounded text-xs font-black">{{ $discount }}% OFF</span>
                    @endif
                </div>

                <!-- Actions Form (Add to Cart / Devis) -->
                <form action="{{ route('shop.addToCart', $product->id) }}" method="POST" class="space-y-6">
                    @csrf

                    <!-- Real Product Options -->
                    @if($product->options->count() > 0)
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
                        @foreach($product->options->groupBy('name') as $optName => $opts)
                        <div class="space-y-3">
                            <label class="text-sm font-bold text-navy-900 uppercase tracking-tighter italic">{{ $optName }}</label>
                            <select name="options[{{ $optName }}]" 
                                @change="updateOption('{{ $optName }}', parseFloat($event.target.options[$event.target.selectedIndex].dataset.price || 0))"
                                class="w-full border-gray-200 rounded-lg text-sm focus:ring-gold-500 focus:border-gold-500">
                                <option value="" data-price="0">-- Choisir --</option>
                                @foreach($opts as $opt)
                                <option value="{{ $opt->id }}" data-price="{{ $opt->price }}">{{ $opt->value }} (+{{ number_format($opt->price, 0, ',', ' ') }} F)</option>
                                @endforeach
                            </select>
                        </div>
                        @endforeach
                    </div>
                    @endif

                    <!-- Personalization / Customization -->
                    <div class="space-y-2 bg-gray-50/50 p-4 rounded-xl border border-gray-100 mb-6">
                        <label class="text-xs font-black text-navy-900 uppercase tracking-widest block italic">
                            Personnalisation de la configuration (Optionnel)
                        </label>
                        <p class="text-[10px] text-gray-400 font-medium">Spécifiez vos exigences sur mesure (ex: RAM de 32GB, disque de 1To, etc.)</p>
                        <textarea name="customization" rows="2" 
                            placeholder="Ex: Je souhaite ce produit avec 32 Go de RAM et un disque de 1 To SSD." 
                            class="mt-1 w-full border-gray-200 rounded-lg text-xs focus:ring-gold-500 focus:border-gold-500 bg-white placeholder-gray-300"></textarea>
                    </div>

                    <!-- Wholesale Pricing Offer Card -->
                    @if($product->wholesale_qty && $product->wholesale_qty >= 2 && $product->wholesale_discount_rate > 0)
                    <div class="mb-8 p-4 rounded-xl border border-gold-200 bg-gold-50/30 flex items-start gap-3">
                        <div class="p-2 rounded-lg bg-gold-100 text-gold-600 flex-shrink-0">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <div class="space-y-1">
                            <span class="text-xs font-bold text-gold-600 uppercase tracking-widest block">Offre de Gros</span>
                            <p class="text-xs text-navy-950 font-medium">
                                Commandez au moins <span class="font-black text-navy-900">{{ $product->wholesale_qty }} unités</span> et bénéficiez de <span class="font-black text-gold-600">-{{ number_format($product->wholesale_discount_rate, 0) }}%</span> de réduction unitaire !
                            </p>
                            @if($product->wholesale_discount_limit && $product->wholesale_discount_limit > 0)
                                <span class="text-[10px] text-gray-500 block italic">
                                    * Réduction plafonnée à {{ number_format($product->wholesale_discount_limit, 0, ',', ' ') }} FCFA par article.
                                </span>
                            @endif
                        </div>
                    </div>
                    @endif

                    <div class="flex flex-col gap-4">
                        <div class="flex items-center gap-4">
                            <div x-data="{ qty: 1 }" class="flex items-center border-2 border-gray-100 rounded-lg p-1 bg-gray-50">
                                <button type="button" @click="if(qty > 1) qty--" class="w-10 h-10 flex items-center justify-center text-navy-900 hover:bg-white rounded transition-colors">-</button>
                                <input type="number" name="quantity" x-model="qty" class="w-12 text-center border-none bg-transparent font-bold focus:ring-0 text-navy-900" min="1" {!! !$product->isPreorderable() ? 'max="'.$product->stock.'"' : '' !!}>
                                <button type="button" @click="if({{ $product->isPreorderable() ? 'true' : 'qty < '.$product->stock }}) qty++" class="w-10 h-10 flex items-center justify-center text-navy-900 hover:bg-white rounded transition-colors">+</button>
                            </div>
                            <button type="submit" class="flex-grow {{ $product->isPreorderable() ? 'bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg shadow-sm' : 'btn-primary-gold' }} h-12 uppercase tracking-widest text-xs flex items-center justify-center gap-4 disabled:opacity-50 disabled:cursor-not-allowed" {{ $product->stock <= 0 && !$product->isPreorderable() ? 'disabled' : '' }}>
                                {{ $product->isPreorderable() ? 'Précommander' : 'Ajouter au Panier' }}
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                            </button>
                        </div>

                        <!-- hidden product_id for quote request -->
                        <input type="hidden" name="product_id" value="{{ $product->id }}">
                        
                        @auth
                        <button type="submit" formaction="{{ route('shop.requestQuote') }}" class="w-full border-2 border-navy-900 text-navy-900 hover:bg-navy-900 hover:text-white h-12 uppercase tracking-widest text-xs font-bold transition-all rounded-lg flex items-center justify-center gap-2">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                            Demander un Devis Personnalisé
                        </button>
                        <a href="{{ route('dashboard.savings.create', ['product_id' => $product->id]) }}" class="w-full border-2 border-gold-500 text-gold-600 hover:bg-gold-500 hover:text-navy-900 h-12 uppercase tracking-widest text-xs font-black transition-all rounded-lg flex items-center justify-center gap-2">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                            Commencer une Épargne Produit
                        </a>
                        @else
                        <a href="{{ route('login') }}" class="w-full border-2 border-dashed border-gray-300 text-gray-500 hover:border-navy-900 hover:text-navy-900 h-12 uppercase tracking-widest text-xs font-bold transition-all rounded-lg flex items-center justify-center gap-2">
                            Se connecter pour Devis Personnalisé
                        </a>
                        <a href="{{ route('login') }}" class="w-full border-2 border-dashed border-gold-300 text-gold-500 hover:border-gold-500 hover:text-gold-600 h-12 uppercase tracking-widest text-xs font-bold transition-all rounded-lg flex items-center justify-center gap-2">
                            Se connecter pour commencer une épargne
                        </a>
                        @endauth
                    </div>
                </form>
            </div>

                <!-- Features Badges -->
                <div class="mt-auto pt-8 border-t border-gray-50 flex items-center gap-6">
                    <span class="flex items-center gap-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                        <svg class="w-4 h-4 text-gold-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04c0 4.835 1.355 9.347 3.718 13.191A11.96 11.96 0 0012 21.481c2.901 0 5.537-.94 7.653-2.545a11.959 11.959 0 013.718-13.191z"/></svg>
                        Paiement Sécurisé
                    </span>
                    <span class="flex items-center gap-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                        <svg class="w-4 h-4 text-gold-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/></svg>
                        Expédition 24H
                    </span>
                    @if($product->warranty_duration_months)
                    <span class="flex items-center gap-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                        <svg class="w-4 h-4 text-gold-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"/></svg>
                        Garantie {{ $product->warranty_duration_months }} Mois
                    </span>
                    @endif
                </div>
            </div>
        </div>

        <!-- Tabs Section -->
        <div x-data="{ tab: 'description' }" class="border border-gray-100 rounded-2xl overflow-hidden mb-16">
            <div class="flex bg-gray-50 border-b border-gray-100 overflow-x-auto">
                <button @click="tab = 'description'" :class="tab === 'description' ? 'bg-white border-b-2 border-gold-500 text-navy-900' : 'text-gray-400 hover:text-navy-900'" class="px-8 py-5 text-xs font-bold uppercase tracking-widest transition-all">Description de l'Article</button>
                <button @click="tab = 'specs'" :class="tab === 'specs' ? 'bg-white border-b-2 border-gold-500 text-navy-900' : 'text-gray-400 hover:text-navy-900'" class="px-8 py-5 text-xs font-bold uppercase tracking-widest transition-all">Fiche Technique</button>
                <button @click="tab = 'shipping'" :class="tab === 'shipping' ? 'bg-white border-b-2 border-gold-500 text-navy-900' : 'text-gray-400 hover:text-navy-900'" class="px-8 py-5 text-xs font-bold uppercase tracking-widest transition-all">Livraison & Garanties</button>
                <button @click="tab = 'reviews'" :class="tab === 'reviews' ? 'bg-white border-b-2 border-gold-500 text-navy-900' : 'text-gray-400 hover:text-navy-900'" class="px-8 py-5 text-xs font-bold uppercase tracking-widest transition-all">Avis Clients</button>
            </div>
            <div class="p-8 lg:p-12">
                <div x-show="tab === 'description'" x-transition class="grid grid-cols-1 lg:grid-cols-3 gap-12">
                    <div class="lg:col-span-2 prose prose-navy max-w-none text-sm leading-8 text-gray-500">
                        <p>{{ $product->description }}</p>
                    </div>
                </div>
                <div x-show="tab === 'specs'" x-transition class="max-w-3xl space-y-6">
                    @if($product->fiche_technique)
                    <div class="p-4 rounded-xl border border-navy-100 bg-navy-50/50 flex items-center justify-between gap-4">
                        <div class="flex items-center gap-3">
                            <div class="p-2 rounded-lg bg-red-100 text-red-600">
                                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clip-rule="evenodd"/></svg>
                            </div>
                            <div>
                                <h4 class="text-xs font-bold text-navy-900 uppercase tracking-wider">Fiche Technique PDF</h4>
                                <p class="text-[11px] text-gray-500">Consultez ou téléchargez le document officiel du fabricant.</p>
                            </div>
                        </div>
                        <a href="{{ asset('storage/' . $product->fiche_technique) }}" target="_blank"
                           class="px-4 py-2 bg-navy-900 hover:bg-navy-950 text-white rounded-lg text-xs font-black uppercase tracking-wider transition-colors flex items-center gap-1.5 shadow-sm">
                            Télécharger
                            <svg class="w-4 h-4 text-gold-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        </a>
                    </div>
                    @endif

                    <table class="w-full text-sm">
                        <tbody class="divide-y divide-gray-100 italic">
                            @if(is_array($product->specs) || is_object($product->specs))
                                @foreach($product->specs as $key => $value)
                                <tr class="hover:bg-gray-50 transition-colors">
                                    <td class="py-4 font-bold text-navy-900 uppercase tracking-tighter w-1/3">{{ $key }}</td>
                                    <td class="py-4 text-gray-500">{{ $value }}</td>
                                </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
                <div x-show="tab === 'shipping'" x-transition class="max-w-3xl text-sm leading-8 text-gray-500 space-y-4">
                    <h4 class="font-bold text-navy-900 uppercase tracking-tighter italic">Garantie Client</h4>
                    <p>Ce produit bénéficie d'une garantie de <strong class="text-navy-900">{{ $product->warranty_duration_months ?? 12 }} mois</strong> (soit {{ ($product->warranty_duration_months ?? 12) % 12 === 0 ? (($product->warranty_duration_months ?? 12) / 12) . ' an(s)' : ($product->warranty_duration_months ?? 12) . ' mois' }}) à compter de la date d'achat.</p>
                    <h4 class="font-bold text-navy-900 uppercase tracking-tighter italic mt-6">Livraison & Expédition</h4>
                    <p>Livraison rapide et sécurisée sous 24 à 48 heures. Suivi en temps réel de votre colis depuis votre tableau de bord.</p>
                </div>
            </div>
        </div>

        <!-- Related Products Grid -->
        <div class="space-y-8">
            <h3 class="text-xl font-bold text-navy-900 uppercase tracking-tighter italic">Recommandations pour vous</h3>
            @php
                $relatedProducts = \App\Models\Product::where('category_id', $product->category_id)->where('id', '!=', $product->id)->take(4)->get();
            @endphp

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                @foreach($relatedProducts as $rel)
                <div class="bg-white border border-gray-100 rounded-lg p-4 group hover:shadow-xl hover:border-gold-200 transition-all duration-300">
                    <a href="{{ route('shop.show', $rel->slug) }}" class="block">
                        <div class="relative aspect-square mb-4 bg-gray-50 rounded-md overflow-hidden flex items-center justify-center p-4">
                            @php
                                $rPath = $rel->image ?: $rel->images->first()->path ?? null;
                                $rImgUrl = $rPath ? (preg_match('#^/?storage/#', $rPath) ? $rPath : '/storage/'.ltrim($rPath, '/')) : asset('logo.jpeg');
                            @endphp
                            <img src="{{ $rImgUrl }}" alt="{{ $rel->name }}" class="max-h-full max-w-full object-contain group-hover:scale-110 transition-transform duration-500">
                        </div>
                        <div class="space-y-2">
                            <h3 class="text-sm font-medium text-navy-900 line-clamp-2 h-10 group-hover:text-gold-600 transition-colors">
                                {{ $rel->name }}
                            </h3>
                            <span class="text-lg font-black text-navy-900">{{ number_format($rel->price, 0, ',', ' ') }} <span class="text-[10px]">CFA</span></span>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection
