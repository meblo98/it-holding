<?php

namespace App\Models;

use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    // Rôles disponibles
    const ROLES = [
        'admin'       => 'Administrateur',
        'dg'          => 'Directeur Général',
        'commercial'  => 'Commercial',
        'comptable'   => 'Comptable',
        'magasinier'  => 'Magasinier',
        'technicien'  => 'Technicien',
        'livreur'     => 'Livreur',
        'client'      => 'Client',
        'partner'     => 'Partenaire',
    ];

    // Catégories du réseau professionnel, voir cahier des charges §3-9.
    // Un utilisateur avec role=partner se décline en l'une de ces catégories.
    const PARTNER_TYPES = [
        'commercial'  => 'Partenaire commercial',
        'apporteur'   => 'Apporteur d\'affaires',
        'revendeur'   => 'Revendeur',
        'freelance'   => 'Freelance',
        'prestataire' => 'Prestataire / Expert',
        'createur'    => 'Créateur / Affilié',
    ];

    protected $fillable = [
        'name', 'email', 'password', 'photo', 'is_admin', 'role',
        'username', 'phone', 'country', 'state', 'zip_code', 'address',
        'billing_first_name', 'billing_last_name', 'billing_address',
        'billing_city', 'billing_zip',
        'shipping_first_name', 'shipping_last_name', 'shipping_address',
        'shipping_city', 'shipping_zip',
        'partner_code', 'partner_status', 'partner_type',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password'          => 'hashed',
            'is_admin'          => 'boolean',
        ];
    }

    // ── Role helpers ────────────────────────────────────────────────────────
    public function hasRole(string ...$roles): bool
    {
        if ($this->is_admin || $this->role === 'admin') return true;
        return in_array($this->role, $roles);
    }

    public function isAdmin(): bool       { return $this->is_admin || $this->role === 'admin'; }
    public function isDG(): bool          { return $this->hasRole('dg'); }
    public function isCommercial(): bool  { return $this->hasRole('commercial'); }
    public function isComptable(): bool   { return $this->hasRole('comptable'); }
    public function isMagasinier(): bool  { return $this->hasRole('magasinier'); }
    public function isTechnicien(): bool  { return $this->hasRole('technicien'); }
    public function isLivreur(): bool     { return $this->hasRole('livreur'); }
    public function isPartner(): bool     { return $this->role === 'partner' && $this->partner_status === 'approved'; }
    public function isPartnerPending(): bool { return $this->role === 'partner' && $this->partner_status === 'pending'; }

    public function isStaff(): bool
    {
        return $this->is_admin || in_array($this->role, ['admin', 'dg', 'commercial', 'comptable', 'magasinier', 'technicien', 'livreur']);
    }

    protected static ?array $cachedPermissions = null;

    public function hasPermission(string $module): bool
    {
        if ($this->isAdmin()) {
            return true;
        }

        if (!$this->isStaff()) {
            return false;
        }

        if (self::$cachedPermissions === null) {
            self::$cachedPermissions = \App\Models\RolePermission::pluck('permissions', 'role')->toArray();
        }

        $rolePermissions = self::$cachedPermissions[$this->role] ?? null;

        if (is_array($rolePermissions)) {
            return in_array($module, $rolePermissions);
        }

        return false;
    }

    public function getRoleLabelAttribute(): string
    {
        return self::ROLES[$this->role] ?? ucfirst($this->role);
    }

    public function getPartnerTypeLabelAttribute(): ?string
    {
        if (!$this->partner_type) {
            return null;
        }
        return self::PARTNER_TYPES[$this->partner_type] ?? ucfirst($this->partner_type);
    }

    // ── Relations ────────────────────────────────────────────────────────────
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function client()
    {
        return $this->hasOne(Client::class);
    }

    public function promoCodes()
    {
        return $this->hasMany(PartnerPromoCode::class, 'partner_id');
    }

    public function commissions()
    {
        return $this->hasMany(PartnerCommission::class, 'partner_id');
    }

    public function prospects()
    {
        return $this->hasMany(PartnerProspect::class, 'partner_id');
    }

    public function scheduledPosts()
    {
        return $this->hasMany(PartnerScheduledPost::class, 'user_id');
    }

    public function professionalProfile()
    {
        return $this->hasOne(ProfessionalProfile::class);
    }

    public function contractAcceptances()
    {
        return $this->hasMany(ContractAcceptance::class);
    }

    public function userBadges()
    {
        return $this->hasMany(UserBadge::class);
    }

    public function missionApplications()
    {
        return $this->hasMany(MissionApplication::class);
    }

    public function validBadges()
    {
        return $this->userBadges()->valid()->with('badge');
    }

    /**
     * The contract currently in force for this user's category that they
     * have not yet accepted, or null if none applies / already accepted
     * (doc §21-22, §64 — blocage du versement de commission tant que le
     * contrat en vigueur n'est pas accepté).
     */
    public function pendingContract(): ?Contract
    {
        if (!$this->partner_type) {
            return null;
        }

        $contract = Contract::currentFor($this->partner_type);
        if (!$contract) {
            return null;
        }

        $accepted = $this->contractAcceptances()->where('contract_id', $contract->id)->exists();

        return $accepted ? null : $contract;
    }

    public function hasAcceptedCurrentContract(): bool
    {
        return $this->pendingContract() === null;
    }

    /**
     * Get the user's professional profile, creating it if it doesn't exist yet.
     * Used when a partner/apporteur/freelance... candidacy is approved.
     */
    public function getOrCreateProfessionalProfile(): ProfessionalProfile
    {
        $profile = $this->ensureProfessionalProfile();

        if (!$profile->pro_id) {
            $profile->update(['pro_id' => ProfessionalProfile::generateProId()]);
        }

        return $profile;
    }

    /**
     * Profil pro sans ID public : l'ID ITH-PRO-… n'est attribué qu'à
     * l'approbation (getOrCreateProfessionalProfile), pour qu'aucun profil
     * non approuvé ne soit vérifiable publiquement.
     */
    public function ensureProfessionalProfile(): ProfessionalProfile
    {
        return $this->professionalProfile ?: $this->setRelation(
            'professionalProfile',
            $this->professionalProfile()->create(['verification_level' => 1]) // téléphone + email vérifiés à l'inscription
        )->professionalProfile;
    }

    public function totalCommissionsEarned()
    {
        return $this->commissions()->where('status', 'paid')->sum('commission_amount');
    }

    public function totalCommissionsPending()
    {
        return $this->commissions()->where('status', 'pending')->sum('commission_amount');
    }

    // ── Photo accessor ───────────────────────────────────────────────────────
    protected function photoUrl(): \Illuminate\Database\Eloquent\Casts\Attribute
    {
        return \Illuminate\Database\Eloquent\Casts\Attribute::make(
            get: function ($value) {
                if ($this->photo) {
                    return asset('storage/' . $this->photo);
                }
                return "https://i.pravatar.cc/150?u=" . $this->id;
            }
        );
    }
}
